# PromptCapture Standalone v2

Local rule engine (140 rules) + optional LLM enhancement. No API key required for rule-based mode.

## Three modes

### Mode 1: Rule-based only (no API key needed)
```bash
node server.js
```
Open http://localhost:3000 · Select "Rule-based" in the toggle · No external calls.

### Mode 2: Rule-based + Claude enhancement
```bash
ANTHROPIC_API_KEY=sk-ant-... node server.js
```
Select "LLM-enhanced → Claude" in the UI toggle.

### Mode 3: Rule-based + Custom endpoint (MetLife METIQ, Azure OpenAI, etc.)
```bash
CUSTOM_ENDPOINT_URL=https://metiq.metlife.com/v1/chat/completions \
CUSTOM_ENDPOINT_KEY=your-token \
CUSTOM_ENDPOINT_MODEL=gpt-4o \
node server.js
```
Select "LLM-enhanced → Custom / METIQ" in the UI toggle.
The server proxies requests internally — no CORS issues with internal endpoints.

## Windows (Command Prompt)
```cmd
set ANTHROPIC_API_KEY=sk-ant-...
node server.js
```

## Windows (PowerShell)
```powershell
$env:ANTHROPIC_API_KEY="sk-ant-..."
$env:CUSTOM_ENDPOINT_URL="https://metiq.metlife.com/v1/chat/completions"
node server.js
```

## What it does
- Analyzes prompts against 140+ PromptGuard guardrails (runs locally — instant, free, offline)
- Shows score, grade, violations with impact levels
- Shows "How you used it" vs "How you should have used it" (Before/After)
- Builds your personal pattern profile over time
- Exports JSON compatible with PromptGuard v3 `promptguard_import_patterns`

## Endpoints
- GET  /config         — returns which LLM options are available on this server
- POST /analyze-claude — proxies to Anthropic API (requires ANTHROPIC_API_KEY)
- POST /analyze-custom — proxies to custom endpoint (requires CUSTOM_ENDPOINT_URL)
