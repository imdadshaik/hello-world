// PromptCapture Standalone Server v2
// Supports: rule-based (no API), Claude, and custom endpoint (METIQ / Azure OpenAI)
// 
// Usage:
//   ANTHROPIC_API_KEY=sk-ant-... node server.js        (Claude + rule-based)
//   node server.js                                      (rule-based only — no API key needed)
//
// For custom endpoint (MetLife METIQ):
//   CUSTOM_ENDPOINT_URL=https://metiq.metlife.com/v1/chat/completions
//   CUSTOM_ENDPOINT_KEY=your-token           (optional)
//   CUSTOM_ENDPOINT_MODEL=gpt-4o             (optional, default: gpt-4o)

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PORT = process.env.PORT || 3000;
const ANTHROPIC_KEY = process.env.ANTHROPIC_API_KEY || '';
const CUSTOM_URL = process.env.CUSTOM_ENDPOINT_URL || '';
const CUSTOM_KEY = process.env.CUSTOM_ENDPOINT_KEY || '';
const CUSTOM_MODEL = process.env.CUSTOM_ENDPOINT_MODEL || 'gpt-4o';

console.log('\n⚡  PromptCapture v2 — starting...');
console.log('   Rule-based analysis: ✅ always available (no API needed)');
console.log('   Claude API:          ' + (ANTHROPIC_KEY ? '✅ configured' : '❌ set ANTHROPIC_API_KEY to enable'));
console.log('   Custom endpoint:     ' + (CUSTOM_URL ? '✅ ' + CUSTOM_URL : '❌ set CUSTOM_ENDPOINT_URL to enable (for METIQ etc.)'));
console.log('');

// ── proxy helper ─────────────────────────────────────────────────────────────
function proxyPost(apiUrl, reqBody, extraHeaders) {
  return new Promise((resolve, reject) => {
    const parsed = new URL(apiUrl);
    const isHttps = parsed.protocol === 'https:';
    const options = {
      hostname: parsed.hostname,
      port: parsed.port || (isHttps ? 443 : 80),
      path: parsed.pathname + parsed.search,
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...extraHeaders },
    };
    const body = typeof reqBody === 'string' ? reqBody : JSON.stringify(reqBody);
    options.headers['Content-Length'] = Buffer.byteLength(body);

    const transport = isHttps ? https : http;
    const req = transport.request(options, (res) => {
      let data = '';
      res.on('data', d => data += d);
      res.on('end', () => resolve({ status: res.statusCode, body: data }));
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

const server = http.createServer(async (req, res) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
  };

  if (req.method === 'OPTIONS') {
    res.writeHead(204, corsHeaders);
    res.end();
    return;
  }

  const parsedUrl = url.parse(req.url);

  // ── POST /analyze-claude ─────────────────────────────────────────────────
  if (req.method === 'POST' && parsedUrl.pathname === '/analyze-claude') {
    if (!ANTHROPIC_KEY) {
      res.writeHead(400, { ...corsHeaders, 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: { message: 'ANTHROPIC_API_KEY not set on server. Start with: ANTHROPIC_API_KEY=sk-ant-... node server.js' } }));
      return;
    }
    let body = '';
    req.on('data', d => body += d);
    req.on('end', async () => {
      try {
        const result = await proxyPost('https://api.anthropic.com/v1/messages', body, {
          'x-api-key': ANTHROPIC_KEY,
          'anthropic-version': '2023-06-01',
        });
        res.writeHead(result.status, { ...corsHeaders, 'Content-Type': 'application/json' });
        res.end(result.body);
      } catch (e) {
        res.writeHead(500, { ...corsHeaders, 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: { message: e.message } }));
      }
    });
    return;
  }

  // ── POST /analyze-custom ─────────────────────────────────────────────────
  if (req.method === 'POST' && parsedUrl.pathname === '/analyze-custom') {
    if (!CUSTOM_URL) {
      res.writeHead(400, { ...corsHeaders, 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: { message: 'CUSTOM_ENDPOINT_URL not set. Start with: CUSTOM_ENDPOINT_URL=https://... node server.js' } }));
      return;
    }
    let body = '';
    req.on('data', d => body += d);
    req.on('end', async () => {
      try {
        const parsed = JSON.parse(body);
        // Use configured model/endpoint if not overridden
        if (!parsed.model) parsed.model = CUSTOM_MODEL;
        const headers = {};
        if (CUSTOM_KEY) headers['Authorization'] = 'Bearer ' + CUSTOM_KEY;
        const result = await proxyPost(CUSTOM_URL, JSON.stringify(parsed), headers);
        res.writeHead(result.status, { ...corsHeaders, 'Content-Type': 'application/json' });
        res.end(result.body);
      } catch (e) {
        res.writeHead(500, { ...corsHeaders, 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: { message: e.message } }));
      }
    });
    return;
  }

  // ── GET /config ──────────────────────────────────────────────────────────
  if (req.method === 'GET' && parsedUrl.pathname === '/config') {
    res.writeHead(200, { ...corsHeaders, 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      claudeAvailable: Boolean(ANTHROPIC_KEY),
      customAvailable: Boolean(CUSTOM_URL),
      customModel: CUSTOM_MODEL,
      customUrlHint: CUSTOM_URL ? CUSTOM_URL.slice(0, 40) + '...' : null,
    }));
    return;
  }

  // ── Static files ─────────────────────────────────────────────────────────
  const filePath = parsedUrl.pathname === '/' ? '/public/index.html' : '/public' + parsedUrl.pathname;
  const fullPath = path.join(__dirname, filePath);
  const ext = path.extname(fullPath);
  const mime = { '.html': 'text/html', '.js': 'text/javascript', '.json': 'application/json', '.css': 'text/css' };

  fs.readFile(fullPath, (err, data) => {
    if (err) { res.writeHead(404, corsHeaders); res.end('Not found'); return; }
    res.writeHead(200, { ...corsHeaders, 'Content-Type': mime[ext] || 'text/plain' });
    res.end(data);
  });
});

server.listen(PORT, () => {
  console.log('✅  PromptCapture running at http://localhost:' + PORT);
  console.log('   Open this URL in your browser\n');
});
